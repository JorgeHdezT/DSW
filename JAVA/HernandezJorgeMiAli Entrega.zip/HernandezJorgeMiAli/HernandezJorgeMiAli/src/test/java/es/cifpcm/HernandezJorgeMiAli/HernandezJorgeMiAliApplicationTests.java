package es.cifpcm.HernandezJorgeMiAli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HernandezJorgeMiAliApplicationTests {

	@Test
	void contextLoads() {
	}

}
