package es.cifpcm.HernandezJorgeMiAli.controller;

import es.cifpcm.HernandezJorgeMiAli.model.CarritoComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/carrito")
public class CarritoController {

    @Autowired
    private CarritoComponent carritoComponent;

    @GetMapping
    public String mostrarCarrito(Model model) {
        model.addAttribute("carrito", carritoComponent.getCarrito());
        return "carrito";
    }
}

