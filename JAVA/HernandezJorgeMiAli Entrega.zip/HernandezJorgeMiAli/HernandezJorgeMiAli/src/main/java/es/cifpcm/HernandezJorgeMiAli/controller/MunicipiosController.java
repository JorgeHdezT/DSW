package es.cifpcm.HernandezJorgeMiAli.controller;

import es.cifpcm.HernandezJorgeMiAli.data.servicios.MunicipiosService;

import es.cifpcm.HernandezJorgeMiAli.model.Municipios;
import jakarta.validation.Valid;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Validated
@RestController
@RequestMapping("/municipios")
public class MunicipiosController {

    @Autowired
    private MunicipiosService municipiosService;

    @PostMapping
    public String save(@Valid @RequestBody Municipios vO) {
        return municipiosService.save(vO).toString();
    }

    @DeleteMapping("/{id}")
    public void delete(@Valid @NotNull @PathVariable("id") Integer id) {
        municipiosService.delete(id);
    }

    @PutMapping("/{id}")
    public void update(@Valid @NotNull @PathVariable("id") Integer id,
                       @Valid @RequestBody Municipios vO) {
        municipiosService.update(id, vO);
    }

    @GetMapping("/{id}")
    public Municipios getById(@Valid @NotNull @PathVariable("id") Integer id) {
        return municipiosService.getById(id);
    }

    @GetMapping
    public Page<Municipios> query(@Valid Municipios vO) {
        return municipiosService.query(vO);
    }
}
