package es.cifpcm.HernandezJorgeMiAli.controller;

import es.cifpcm.HernandezJorgeMiAli.data.repositorios.PedidosRepository;
import es.cifpcm.HernandezJorgeMiAli.data.servicios.CartService;
import es.cifpcm.HernandezJorgeMiAli.data.servicios.MunicipiosService;
import es.cifpcm.HernandezJorgeMiAli.data.servicios.PedidosService;
import es.cifpcm.HernandezJorgeMiAli.data.servicios.ProductofferService;
import es.cifpcm.HernandezJorgeMiAli.model.Municipios;
import es.cifpcm.HernandezJorgeMiAli.model.Pedidos;
import es.cifpcm.HernandezJorgeMiAli.model.Productoffer;
import jakarta.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import org.springframework.validation.BindingResult;

import org.springframework.ui.Model;

import es.cifpcm.HernandezJorgeMiAli.model.CarritoComponent;

import java.util.ArrayList;
import java.util.List;

@Controller
public class MainController {

    //Declaro la lista que tendrá el carrito.
    public List<Productoffer> carrito = new ArrayList<>();


    @Autowired
    private ProductofferService productOfferService;

    @Autowired
    private CartService cartService;

    @GetMapping("/")
    public String mostrarIndex() {
        return "index";
    }

    @GetMapping("/Carrito")
    public String mostrarCarrito() {
        return "carrito";
    }


    @GetMapping("/Pedidos")
    public String mostrarPedidos() {
        return "pedidos";
    }

    @GetMapping("/Identificarse")
    public String mostrarLogin() {
        return "login";
    }

    @GetMapping("/Registrarse")
    public String mostrarRegistro() {
        return "registro";
    }

    @GetMapping("/Productos")
    public ModelAndView showProductList() {
        List<Productoffer> listaProductos = productOfferService.getAllProductOffers();
        ModelAndView modelAndView = new ModelAndView("Productos");
        modelAndView.addObject("listaProductos", listaProductos);
        return modelAndView;
    }


    //Crear productos:
    @Autowired
    private MunicipiosService municipiosService;

    @GetMapping("/CrearProducto")
    public ModelAndView showCreateProductForm() {
        List<Municipios> municipios = municipiosService.getAllMunicipios();
        ModelAndView modelAndView = new ModelAndView("CrearProducto");
        modelAndView.addObject("newProduct", new Productoffer());
        modelAndView.addObject("municipios", municipios);
        return modelAndView;
    }

    @PostMapping("/CrearProducto")
    public ModelAndView createProduct(@Valid @ModelAttribute("newProduct") Productoffer newProduct, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            // Manejar los errores de validación, por ejemplo, redirigir de nuevo al formulario
            ModelAndView modelAndView = new ModelAndView("CrearProducto");
            modelAndView.addObject("municipios", municipiosService.getAllMunicipios());
            return modelAndView;
        }

        productOfferService.save(newProduct);

        // Redirige a la lista de productos después de añadir un nuevo producto
        return new ModelAndView("redirect:/Productos");
    }

    @PostMapping("/deleteProduct")
    public String deleteProduct(@RequestParam Integer productId) {
        // Lógica para eliminar el producto con el ID proporcionado
        productOfferService.delete(productId);

        // Redirigir a la página de productos después de la eliminación
        return "redirect:/Productos";
    }


    @Autowired
    private PedidosService pedidosService; // Reemplaza con el repositorio real

    @PostMapping("/realizarPedido")
    public ModelAndView realizarPedido() {
        // Lógica para agregar los productos del carrito a la tabla de Pedidos
        for (Productoffer producto : carrito) {
            Pedidos pedido = new Pedidos();
            BeanUtils.copyProperties(producto, pedido);

            // Guarda el pedido en la tabla Pedidos utilizando el servicio correspondiente
            Integer pedidoId = pedidosService.save(pedido);
        }

        // Limpiar el carrito después de hacer el pedido
        carrito.clear();

        // Obtener la lista de productos desde la tabla de Pedidos (aquí debes implementar la lógica)
        List<Productoffer> listaPedidos = new ArrayList<>(); // Reemplaza esto con la lógica real

        ModelAndView modelAndView = new ModelAndView("pedidos");
        modelAndView.addObject("listaPedidos", listaPedidos);
        modelAndView.addObject("mensaje", "Pedido realizado con éxito.");
        return modelAndView;
    }
}
