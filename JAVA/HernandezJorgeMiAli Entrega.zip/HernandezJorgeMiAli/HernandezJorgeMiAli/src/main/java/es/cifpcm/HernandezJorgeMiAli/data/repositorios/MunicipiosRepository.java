package es.cifpcm.HernandezJorgeMiAli.data.repositorios;

import es.cifpcm.HernandezJorgeMiAli.model.Municipios;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface MunicipiosRepository extends JpaRepository<Municipios, Integer>, JpaSpecificationExecutor<Municipios> {

}