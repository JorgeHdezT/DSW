package es.cifpcm.HernandezJorgeMiAli.model;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "pedidos")
public class Pedidos implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id_pedido", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idPedido;

    @Column(name = "usuario", nullable = false)
    private String usuario;

    @Column(name = "precio_total", nullable = false)
    private Float precioTotal;

    @Column(name = "fecha_pedido", nullable = false)
    private Date fechaPedido;

    @Column(name = "productos_comprados", nullable = false)
    private String productosComprados;

    public void setIdPedido(Integer idPedido) {
        this.idPedido = idPedido;
    }

    public Integer getIdPedido() {
        return idPedido;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setPrecioTotal(Float precioTotal) {
        this.precioTotal = precioTotal;
    }

    public Float getPrecioTotal() {
        return precioTotal;
    }

    public void setFechaPedido(Date fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public Date getFechaPedido() {
        return fechaPedido;
    }

    public void setProductosComprados(String productosComprados) {
        this.productosComprados = productosComprados;
    }

    public String getProductosComprados() {
        return productosComprados;
    }

    @Override
    public String toString() {
        return "Pedidos{" +
                "idPedido=" + idPedido + '\'' +
                "usuario=" + usuario + '\'' +
                "precioTotal=" + precioTotal + '\'' +
                "fechaPedido=" + fechaPedido + '\'' +
                "productosComprados=" + productosComprados + '\'' +
                '}';
    }
}
