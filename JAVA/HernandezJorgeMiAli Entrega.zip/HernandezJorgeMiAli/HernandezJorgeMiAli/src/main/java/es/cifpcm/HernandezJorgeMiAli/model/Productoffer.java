package es.cifpcm.HernandezJorgeMiAli.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

import java.io.Serializable;

@Entity
@Table(name = "productoffer")
public class Productoffer implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "product_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer productId;

    @Column(name = "product_name", nullable = false)
    @NotBlank(message = "El nombre del producto no puede estar en blanco")
    private String productName;

    @Column(name = "product_price")
    @Positive(message = "El precio del producto debe ser un número positivo")
    private Float productPrice;

    @Column(name = "product_picture")
    private String productPicture;

    @Column(name = "id_municipio", nullable = false)
    private Integer idMunicipio;

    @Column(name = "product_stock", nullable = false)
    @PositiveOrZero(message = "El stock del producto debe ser un número positivo o cero")
    private Integer productStock;

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductPrice(Float productPrice) {
        this.productPrice = productPrice;
    }

    public Float getProductPrice() {
        return productPrice;
    }

    public void setProductPicture(String productPicture) {
        this.productPicture = productPicture;
    }

    public String getProductPicture() {
        return productPicture;
    }

    public void setIdMunicipio(Integer idMunicipio) {
        this.idMunicipio = idMunicipio;
    }

    public Integer getIdMunicipio() {
        return idMunicipio;
    }

    public void setProductStock(Integer productStock) {
        this.productStock = productStock;
    }

    public Integer getProductStock() {
        return productStock;
    }

    @Override
    public String toString() {
        return "Productoffer{" +
                "productId=" + productId + '\'' +
                "productName=" + productName + '\'' +
                "productPrice=" + productPrice + '\'' +
                "productPicture=" + productPicture + '\'' +
                "idMunicipio=" + idMunicipio + '\'' +
                "productStock=" + productStock + '\'' +
                '}';
    }
}
