package es.cifpcm.HernandezJorgeMiAli.data.servicios;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class CartService {

    private final Map<Integer, Float> cartItems = new HashMap<>();

    public void addToCart(Integer productId, Float productPrice) {
        cartItems.put(productId, cartItems.getOrDefault(productId, 0.0f) + productPrice);
    }

    public Float getCartTotal() {
        return cartItems.values().stream().reduce(0.0f, Float::sum);
    }
}
