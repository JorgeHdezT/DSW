package es.cifpcm.HernandezJorgeMiAli.controller;

import ch.qos.logback.core.model.Model;
import es.cifpcm.HernandezJorgeMiAli.data.servicios.ProductofferService;

import es.cifpcm.HernandezJorgeMiAli.model.CarritoComponent;
import es.cifpcm.HernandezJorgeMiAli.model.Productoffer;
import jakarta.validation.Valid;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Validated
@RestController
@RequestMapping("/productoffer")
public class ProductofferController {

    @Autowired
    private ProductofferService productofferService;

    @PostMapping
    public String save(@Valid @RequestBody Productoffer vO) {
        return productofferService.save(vO).toString();
    }

    @DeleteMapping("/{id}")
    public void delete(@Valid @NotNull @PathVariable("id") Integer id) {
        productofferService.delete(id);
    }

    @PutMapping("/{id}")
    public void update(@Valid @NotNull @PathVariable("id") Integer id,
                       @Valid @RequestBody Productoffer vO) {
        productofferService.update(id, vO);
    }

    @GetMapping("/{id}")
    public Productoffer getById(@Valid @NotNull @PathVariable("id") Integer id) {
        return productofferService.getById(id);
    }

    @GetMapping
    public Page<Productoffer> query(@Valid Productoffer vO) {
        return productofferService.query(vO);
    }

    @Autowired
    private CarritoComponent carritoComponent;

    // Rest of your methods...

    @PostMapping("/addToCart")
    public ModelAndView addToCart(@RequestParam Integer productId) {
        ModelAndView modelAndView = new ModelAndView("carrito");

        // Obtener el producto con el ID seleccionado
        Productoffer selectedProduct = productofferService.getById(productId);

        // Verificar si el producto existe
        if (selectedProduct != null) {
            // Obtener la lista actual del carrito desde el componente
            List<Productoffer> listaCarrito = carritoComponent.getCarrito();

            // Verificar si el producto ya está en el carrito
            if (!listaCarrito.contains(selectedProduct)) {
                // Agregar el producto seleccionado a la lista del carrito
                listaCarrito.add(selectedProduct);

                // Actualizar la lista del carrito en el componente
                carritoComponent.setCarrito(listaCarrito);

                // Agregar la lista del carrito al modelo para pasarlo a la vista
                modelAndView.addObject("listaCarrito", listaCarrito);
                modelAndView.addObject("mensaje", "Producto agregado al carrito correctamente.");
            } else {
                modelAndView.addObject("mensaje", "El producto ya está en el carrito.");
            }
        } else {
            modelAndView.addObject("mensaje", "El producto con el ID seleccionado no existe.");
        }

        return modelAndView;
    }




}
