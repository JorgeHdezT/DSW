package es.cifpcm.HernandezJorgeMiAli.data.servicios;

import es.cifpcm.HernandezJorgeMiAli.data.repositorios.ProvinciasRepository;
import es.cifpcm.HernandezJorgeMiAli.model.Provincias;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.NoSuchElementException;

@Service
public class ProvinciasService {

    @Autowired
    private ProvinciasRepository provinciasRepository;

    public Integer save(Provincias vO) {
        Provincias bean = new Provincias();
        BeanUtils.copyProperties(vO, bean);
        bean = provinciasRepository.save(bean);
        return bean.getIdProvincia();
    }

    public void delete(Integer id) {
        provinciasRepository.deleteById(id);
    }

    public void update(Integer id, Provincias vO) {
        Provincias bean = requireOne(id);
        BeanUtils.copyProperties(vO, bean);
        provinciasRepository.save(bean);
    }

    public Provincias getById(Integer id) {
        Provincias original = requireOne(id);
        return toDTO(original);
    }

    public Page<Provincias> query(Provincias vO) {
        throw new UnsupportedOperationException();
    }

    private Provincias toDTO(Provincias original) {
        Provincias bean = new Provincias();
        BeanUtils.copyProperties(original, bean);
        return bean;
    }

    private Provincias requireOne(Integer id) {
        return provinciasRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Resource not found: " + id));
    }
}
