package es.cifpcm.HernandezJorgeMiAli.data.servicios;

import es.cifpcm.HernandezJorgeMiAli.data.repositorios.PedidosRepository;
import es.cifpcm.HernandezJorgeMiAli.data.repositorios.ProductofferRepository;
import es.cifpcm.HernandezJorgeMiAli.model.Productoffer;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ProductofferService {

    @Autowired
    private ProductofferRepository productofferRepository;
    @Autowired
    private PedidosRepository pedidosRepository;

    public Integer save(Productoffer vO) {
        Productoffer bean = new Productoffer();
        BeanUtils.copyProperties(vO, bean);
        bean = productofferRepository.save(bean);
        return bean.getProductId();
    }

    public void delete(Integer id) {
        productofferRepository.deleteById(id);
    }

    public void update(Integer id, Productoffer vO) {
        Productoffer bean = requireOne(id);
        BeanUtils.copyProperties(vO, bean);
        productofferRepository.save(bean);
    }

    public Productoffer getById(Integer id) {
        Productoffer original = requireOne(id);
        return toDTO(original);
    }

    public Page<Productoffer> query(Productoffer vO) {
        throw new UnsupportedOperationException();
    }

    private Productoffer toDTO(Productoffer original) {
        Productoffer bean = new Productoffer();
        BeanUtils.copyProperties(original, bean);
        return bean;
    }

    private Productoffer requireOne(Integer id) {
        return productofferRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Resource not found: " + id));
    }

    public List<Productoffer> getAllProductOffers() {
        return productofferRepository.findAll();
    }

}
