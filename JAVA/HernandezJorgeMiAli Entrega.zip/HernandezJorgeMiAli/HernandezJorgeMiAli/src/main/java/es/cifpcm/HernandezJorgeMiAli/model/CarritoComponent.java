package es.cifpcm.HernandezJorgeMiAli.model;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CarritoComponent {

    private List<Productoffer> carrito;

    public CarritoComponent() {
        this.carrito = new ArrayList<>();
    }

    public List<Productoffer> getCarrito() {
        return carrito;
    }

    public void setCarrito(List<Productoffer> carrito) {
        this.carrito = carrito;
    }

    public void clearCarrito() {
        this.carrito.clear();
    }
}

