package es.cifpcm.HernandezJorgeMiAli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HernandezJorgeMiAliApplication {

	public static void main(String[] args) {
		SpringApplication.run(HernandezJorgeMiAliApplication.class, args);
	}

}
