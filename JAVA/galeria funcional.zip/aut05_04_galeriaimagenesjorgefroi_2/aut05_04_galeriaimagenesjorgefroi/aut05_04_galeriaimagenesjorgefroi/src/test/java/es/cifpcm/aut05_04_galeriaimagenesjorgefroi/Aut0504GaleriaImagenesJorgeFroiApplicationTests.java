package es.cifpcm.aut05_04_galeriaimagenesjorgefroi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aut0504GaleriaImagenesJorgeFroiApplicationTests {

	@Test
	void contextLoads() {
	}

}
