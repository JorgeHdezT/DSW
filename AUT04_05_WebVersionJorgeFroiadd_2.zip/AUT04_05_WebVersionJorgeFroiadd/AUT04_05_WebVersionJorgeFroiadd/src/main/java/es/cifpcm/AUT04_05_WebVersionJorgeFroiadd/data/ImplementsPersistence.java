package es.cifpcm.AUT04_05_WebVersionJorgeFroiadd.data;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import es.cifpcm.AUT04_05_WebVersionJorgeFroiadd.model.Farmacia;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ImplementsPersistence implements Persistence{
    private List<Farmacia>farmacias=new ArrayList<>();
    String filePath="C:\\2DAW\\DSW\\JAVA\\23-24\\AUT04_05_WebVersionJorgeFroiadd\\AUT04_05_WebVersionJorgeFroiadd\\src\\main\\resources\\json\\farmacias_web.json";
    File file = new File(filePath);
    private FileReader reader;

    {
        try {
            reader = new FileReader(filePath);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    private final Gson gson = new Gson();
    @Override
    public void readJSON() {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("json/farmacias_web.json")) {
            assert inputStream != null;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
                Type listType = new TypeToken<List<Farmacia>>(){}.getType();
                farmacias = gson.fromJson(br, listType);
            }
        } catch (IOException e) {
            e.printStackTrace(); // Manejo del error
        }
    }

    @Override
    public List<Farmacia> farmacias() {
        return farmacias;
    }

    /*@Override
    public void add(Farmacia farmacia) {
        Type type= new TypeToken<ArrayList<Farmacia>>() {}.getType();
        farmacias = gson.fromJson(reader,type);
        if(farmacias==null){
            farmacias=new ArrayList<>();//inizializar si no es null
        }
        farmacias.add(farmacia);
        updateJSON();
    }

    @Override
    public void updateJSON() {
        try (FileWriter fileWriter = new FileWriter(file)) {
            gson.toJson(farmacias, fileWriter);
            System.out.println("JSON updated");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
}
