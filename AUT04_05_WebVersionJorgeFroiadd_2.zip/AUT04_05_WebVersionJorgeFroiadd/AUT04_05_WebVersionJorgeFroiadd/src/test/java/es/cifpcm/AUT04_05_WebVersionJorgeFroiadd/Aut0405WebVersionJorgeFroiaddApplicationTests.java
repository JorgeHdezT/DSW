package es.cifpcm.AUT04_05_WebVersionJorgeFroiadd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aut0405WebVersionJorgeFroiaddApplicationTests {

	@Test
	void contextLoads() {
	}

}
