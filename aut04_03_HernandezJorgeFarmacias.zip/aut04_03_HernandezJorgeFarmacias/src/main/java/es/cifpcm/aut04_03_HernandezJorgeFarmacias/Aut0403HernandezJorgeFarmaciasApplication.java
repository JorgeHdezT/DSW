package es.cifpcm.aut04_03_HernandezJorgeFarmacias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aut0403HernandezJorgeFarmaciasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aut0403HernandezJorgeFarmaciasApplication.class, args);
	}

}
