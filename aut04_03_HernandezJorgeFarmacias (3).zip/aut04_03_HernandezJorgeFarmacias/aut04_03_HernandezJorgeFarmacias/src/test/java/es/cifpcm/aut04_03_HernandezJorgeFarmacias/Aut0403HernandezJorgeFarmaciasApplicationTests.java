package es.cifpcm.aut04_03_HernandezJorgeFarmacias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aut0403HernandezJorgeFarmaciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
