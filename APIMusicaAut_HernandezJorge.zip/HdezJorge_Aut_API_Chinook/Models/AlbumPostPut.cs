﻿namespace APIMusica_HdezJorge.Models
{
    public class AlbumPostPut
    {
        public int AlbumPostPutId { get; set; }
        public string Title { get; set; }
        public int ArtistId { get; set; }
    }
}
