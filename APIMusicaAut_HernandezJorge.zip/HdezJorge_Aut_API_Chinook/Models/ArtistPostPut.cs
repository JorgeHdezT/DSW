﻿namespace APIMusica_HdezJorge.Models
{
    public class ArtistPostPut
    {
        public int ArtistPostPutId { get; set;}
        public string Nombre { get; set;}

    }
}
